const userHandler = require('./kiko');
require('dotenv').config();
module.exports = {
  BOT_TOKEN:
  "ISI_BOT_TOKEN_LU",
};

;